'use client';

import { useT } from '@/i18n/runtime';
import React from 'react';

interface ResetButtonProps {
  onReset: () => void;
}

export function ResetButton({ onReset }: ResetButtonProps) {
  const t = useT();
  return (
    <button
      onClick={onReset}
      className="btn-ghost text-xs gap-1.5"
      aria-label={t('Reset calculator')}
    >
      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
      </svg>
      {t('Reset')}
    </button>
  );
}
