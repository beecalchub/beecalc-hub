# QA/QC Fixes Applied - BeeCalc Hub

**Date:** April 18, 2026

All 10 recommended issues from the QA/QC audit have been fixed. Summary below.

---

## Priority 1 - Fixed

### ✅ 1.1 Privacy: infrastructure log no longer pushed to public GitHub
Added `BEECALC-HUB-INFRASTRUCTURE-LOG.md` and `QA-QC-REPORT.md` to `.gitignore`.
These stay on your computer but will never be uploaded to your public repo.

### ✅ 1.2 Added sitemap.xml
Created `src/app/sitemap.ts` - Next.js now auto-generates a full sitemap with all
163 URLs (142 calculators + 15 categories + 6 static pages) at
https://beecalchub.com/sitemap.xml. Submit this to Google Search Console.

### ✅ 1.3 Added robots.txt
Created `src/app/robots.ts` - generates robots.txt that allows all crawlers and
points them to the sitemap. Live at https://beecalchub.com/robots.txt.

### ✅ 1.4 Security: patched Next.js
Updated Next.js from a vulnerable version to 16.2.10 (patches the DoS and
middleware-bypass advisories). Ran `npm audit fix` for the rest.
Remaining 5 advisories are all in dev-only build tooling (eslint's `glob`,
`postcss`) and do not affect the production static site.

---

## Priority 2 - Fixed

### ✅ 2.1 "Infinity" bug eliminated site-wide
Modified `src/components/ui/NumberInput.tsx` to clamp typed values to each field's
min/max. Now typing `0` into a divisor field (like "Jars per Case") is impossible -
it clamps to the minimum. One change protected all 142 calculators.

### ✅ 2.2 "NaN" from cleared dates fixed
Added invalid-date guards to all date-based calculators (egg-to-emergence-timeline,
spring-buildup, main-flow-countdown, forage-gap, mating-window, queen-rearing-timeline).
Clearing a date now shows a friendly "Enter valid dates" message instead of "NaN".

### ✅ 2.3 Number formatting applied to 54 generated calculators
Routed raw outputs through the existing formatters (`formatNumber`, `formatCurrency`).
- 49 currency values now show as `$1,234.50` instead of `$1234.5`
- 103 raw numbers now get proper thousands separators and rounding

### ✅ 2.4 Copy-to-clipboard titles cleaned up
Fixed 65 calculators - clicking "Copy" now produces a header like
"Wax Rendering Yield Calculator" instead of the raw slug "wax-rendering-yield".

---

## Priority 3 - Fixed

### ✅ 3.1 Real descriptions for 67 calculators
Replaced generic "Free, practical beekeeping calculator" placeholder text with
unique, keyword-rich descriptions and 3 related-calculator links for every one of
the 67 mass-generated calculators. Big SEO improvement + working "Related
Calculators" sections throughout.

### ✅ 3.2 OpenGraph share image
Created a branded 1200×630 `public/og-image.png` and wired it into metadata.
Sharing any page on Facebook/X/WhatsApp now shows a proper preview card.
Also added `metadataBase` so all OG URLs resolve correctly.

### ✅ 3.3 Custom 404 and error pages
- `src/app/not-found.tsx` - honey-themed 404 with "Browse All Calculators" link
- `src/app/error.tsx` - styled error boundary with "Try Again" button

### ✅ 3.4 Date input accessibility
Added `htmlFor`/`id` pairing to 8 date inputs across 4 calculators so screen
readers correctly associate labels with fields.

### ✅ 3.5 ESLint warning cleared
Ran `eslint --fix`. Zero errors, zero warnings now.

### ✅ 3.6 Domain-accuracy corrections
- **what-jar-price-should-i-charge:** Fixed honey jar math - now treats jar size as
  net weight (a "16 oz" honey jar = 1 lb honey) instead of volume, matching how
  honey is actually sold.
- **queen-cage-candy:** Adjusted to realistic amounts (~0.2 oz sugar per plug
  instead of 0.5 oz).

---

## Verification After All Fixes

| Check | Result |
|---|---|
| Production build | ✅ 167 pages (added sitemap + robots) |
| TypeScript strict | ✅ Zero errors |
| Tests | ✅ 148/148 passing |
| ESLint | ✅ Zero errors, zero warnings |
| Registry ↔ Components | ✅ 142 = 142 |
| Next.js version | ✅ 16.2.10 (patched) |

---

## Not Changed (Intentionally)

- **5 remaining npm audit advisories:** All in dev/build tooling (eslint's glob,
  postcss). Fixing requires breaking upgrades that risk build stability. They do
  not affect your deployed static site. Safe to leave.
- **Calculator count corrected to 142** (was mistakenly called 151 earlier). This
  was a counting error in documentation, not a site change.

---

## What You Should Do After Deploying

1. Push these changes: `git add . && git commit -m "QA fixes: sitemap, robots, formatting, SEO, security" && git push`
2. Wait for Vercel to deploy (~3 min)
3. Submit sitemap to Google Search Console:
   - Go to https://search.google.com/search-console
   - Add/select beecalchub.com
   - Sitemaps → enter `sitemap.xml` → Submit
4. Test share preview: paste https://beecalchub.com into
   https://www.opengraph.xyz to see your new share card
