# BeeCalc Hub - Infrastructure & Deployment Log

**Last updated:** April 18, 2026
**Site:** https://beecalchub.com
**Owner email:** beecalchub@gmail.com

---

## 1. Quick Reference - Most Important Info

| What | Value |
|---|---|
| Live website URL | https://beecalchub.com |
| Vercel preview URL | https://beecalc-hub.vercel.app |
| Owner email | beecalchub@gmail.com |
| Local code folder | `C:\WebVirtual\beecalc-hub` |
| GitHub repository | https://github.com/beecalchub/beecalc-hub |
| Google Analytics ID | G-2CPGZ55BT9 |
| Buy Me a Coffee | https://buymeacoffee.com/beecalchub |
| Stripe Donation | https://donate.stripe.com/8x200k3mE1qH7z46T6eEo00 |

---

## 2. Domain & DNS Setup

### Domain Registration
- **Registrar:** GoDaddy
- **Domain:** beecalchub.com
- **Login URL:** https://godaddy.com
- **Login email:** beecalchub@gmail.com
- **Notes:** Domain was previously pointed to Namecheap nameservers (`dns1.namecheaphosting.com` / `dns2.namecheaphosting.com`). On April 18, 2026, switched back to GoDaddy default nameservers so DNS can be managed directly at GoDaddy.

### DNS Management
- **DNS managed at:** GoDaddy (My Products → beecalchub.com → DNS)
- **Nameservers:**
  - `ns15.domaincontrol.com`
  - `ns16.domaincontrol.com`

### DNS Records (as of April 18, 2026)

| Type | Name | Value | Purpose |
|---|---|---|---|
| **A** | `@` | `216.198.79.1` | Points beecalchub.com to Vercel |
| **CNAME** | `www` | `cname.vercel-dns.com` | Points www.beecalchub.com to Vercel |
| NS | `@` | `ns15.domaincontrol.com.` | GoDaddy nameserver (do not change) |
| NS | `@` | `ns16.domaincontrol.com.` | GoDaddy nameserver (do not change) |
| SOA | `@` | Primary nameserver: ns15... | System record (do not change) |
| CNAME | `_domainconnect` | `_domainconnect.gd.domaincontrol.com.` | GoDaddy admin record (do not change) |
| TXT | `_dmarc` | `v=DMARC1; p=quarantine; adkim=r; aspf=r; rua=mailto:dmarc_rua@onsecureserver.net;` | Email security record (do not change) |

### If You Need to Change DNS

1. Log in to https://godaddy.com
2. Go to **My Products** → find `beecalchub.com` → click **DNS**
3. Click **DNS Records** tab
4. Edit/add records as needed
5. Wait 5-30 minutes for changes to propagate
6. Verify at https://dnschecker.org

---

## 3. Hosting (Vercel)

### Vercel Account
- **Login URL:** https://vercel.com
- **Login method:** "Continue with GitHub" (linked to GitHub account)
- **Plan:** Hobby (FREE)
- **Project name:** beecalc-hub

### Vercel Project Settings
- **Framework:** Next.js (auto-detected)
- **Root directory:** `./`
- **Build command:** Default (npm run build)
- **Output directory:** Default (.next)
- **Install command:** Default (npm install) - uses .npmrc settings
- **Environment variables:** None
- **Production branch:** main

### Vercel URLs
- **Custom domain:** https://beecalchub.com (primary)
- **WWW redirect:** https://www.beecalchub.com → redirects to beecalchub.com
- **Vercel preview URL:** https://beecalc-hub.vercel.app (always works as backup)

### How Deployments Work
- Every `git push` to the `main` branch on GitHub automatically triggers a new build on Vercel
- Build typically takes 2-4 minutes
- Vercel sends an email when deployment completes
- Old deployments are kept and can be rolled back to instantly

### To Roll Back a Deployment
1. Log in to Vercel
2. Go to project → **Deployments** tab
3. Find the previous working deployment
4. Click the three dots `...` → **Promote to Production**

---

## 4. Source Code (GitHub)

### GitHub Account
- **Login URL:** https://github.com
- **Username:** beecalchub
- **Repository:** https://github.com/beecalchub/beecalc-hub
- **Visibility:** Public (free)

### Local Development Setup
- **Local folder:** `C:\WebVirtual\beecalc-hub`
- **Git installed via:** https://git-scm.com/download/win
- **Git config:**
  - user.name: `Alex`
  - user.email: `beecalchub@gmail.com`

### How to Push Updates

Open Git Bash, then:
```bash
cd /c/WebVirtual/beecalc-hub
git status                      # Check what changed (optional)
git add .                       # Stage all changes
git commit -m "Description"     # Save changes locally
git push                        # Upload to GitHub (triggers Vercel deploy)
```

After pushing, Vercel automatically deploys the new version within 2-4 minutes.

### Useful Git Commands

| Command | What it does |
|---|---|
| `git status` | See what files have changed |
| `git add .` | Stage all changes for commit |
| `git commit -m "message"` | Save changes locally with a description |
| `git push` | Upload changes to GitHub (triggers Vercel deploy) |
| `git pull` | Download latest changes from GitHub |
| `git log --oneline` | See recent commit history |

### Important Note About Pasting in Git Bash
- ❌ Ctrl+V does NOT work in Git Bash (causes weird `^[[200~` errors)
- ✅ Right-click in the window to paste
- ✅ Shift+Insert also works

---

## 5. Tech Stack

| Component | Tool/Version |
|---|---|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript (strict mode) |
| Styling | Tailwind CSS 3.4 |
| Hosting | Vercel (Hobby/free tier) |
| Source control | Git + GitHub |
| Domain | GoDaddy |
| Analytics | Google Analytics 4 |
| Testing | Jest (148 tests) |
| Total calculators | 151 active |
| Build output | 165 static pages |

---

## 6. Revenue / Donation Setup

### Buy Me a Coffee
- **URL:** https://buymeacoffee.com/beecalchub
- **Username in code:** `beecalchub`
- **Set in 3 files:**
  - `src/app/page.tsx` (homepage banner)
  - `src/app/support/page.tsx` (dedicated support page)
  - `src/components/calculator/CalculatorShell.tsx` (every calculator page)

### Stripe Donation
- **URL:** https://donate.stripe.com/8x200k3mE1qH7z46T6eEo00
- **Set in same 3 files as Buy Me a Coffee**

### Where Donate Buttons Appear on Site
1. **Homepage** - full banner between categories and beginner section
2. **Every calculator page** - compact banner between results and related calculators (dismissible per session)
3. **Footer** → "Support Us" link → dedicated `/support` page with both buttons prominently displayed

---

## 7. Contact Information

The Contact page (https://beecalchub.com/contact) has three mailto links, all pointing to `beecalchub@gmail.com`:
- **Email** - general inquiries
- **Bug Reports** - pre-filled email template asking for browser/device info
- **Feature Requests** - pre-filled template asking what calculator they want

---

## 8. Local Development

### To Run the Site Locally
```bash
cd C:\WebVirtual\beecalc-hub
npm install              # Only needed first time or after pulling changes
npm run dev             # Starts dev server at http://localhost:3000
```

### To Build for Production (test before pushing)
```bash
npm run build           # Build for production
npm start               # Run production build locally
```

### To Run Tests
```bash
npx jest                # Runs all 148 tests
```

---

## 9. Troubleshooting

### "Site is down / showing wrong page"
1. Check Vercel dashboard - did the latest deployment fail?
2. Check Vercel domains page - is status still "Valid Configuration" ✅?
3. Test the Vercel preview URL: https://beecalc-hub.vercel.app - if this works, the issue is DNS
4. Check DNS at https://dnschecker.org - search `beecalchub.com` for A record, should show `216.198.79.1`

### "Donate button doesn't work"
- Right-click the button → Copy link address → verify it's the correct Stripe URL
- The correct Stripe URL is: `https://donate.stripe.com/8x200k3mE1qH7z46T6eEo00`

### "Buy Me a Coffee button doesn't work"
- Right-click the button → Copy link address → should be `https://www.buymeacoffee.com/beecalchub`

### "I made changes locally but the live site doesn't update"
- Did you commit and push to GitHub? Run: `git status` to check
- Check Vercel dashboard - is there a deployment in progress?
- Check Vercel deployments - did the build fail? Read the build logs

### "Support banner doesn't appear"
- It might be dismissed in your session - open in incognito mode to test
- Or clear browser session storage: DevTools (F12) → Application → Session Storage → delete `beecalc-support-dismissed-v2`

### "Google Analytics not tracking my visits"
- This is normal if you have an ad blocker (uBlock Origin, AdBlock Plus, etc.)
- Test in Incognito mode or different browser to confirm tracking works for real visitors
- Browser tracking protection (Brave, Firefox strict mode) also blocks GA

### "Vercel build fails with npm error / dependency conflict"
- Make sure `.npmrc` exists in project root with `legacy-peer-deps=true`
- This handles the eslint v8 vs eslint-config-next v16 conflict

### "Vercel build fails with file size error / large file"
- Means `node_modules/` got committed by accident
- Verify `.gitignore` exists and contains `node_modules/`
- See section 15 below for full recovery procedure

---

## 10. Recurring Costs

| Service | Cost | Renewal |
|---|---|---|
| Domain (beecalchub.com at GoDaddy) | ~$15-20/year | Annual |
| Vercel hosting | $0 | Free forever (Hobby plan) |
| GitHub | $0 | Free forever (public repos) |
| Google Analytics | $0 | Free forever |
| **Total annual cost** | **~$15-20/year** | |

### Vercel Hobby Plan Limits (More Than Enough)
- 100 GB bandwidth/month (plenty for a calculator site)
- Unlimited deployments
- Free SSL certificate (HTTPS)
- Free custom domain
- If you ever hit limits, can upgrade to Pro at $20/month

---

## 11. Important Dates

| Date | Event |
|---|---|
| April 18, 2026 | Site went live at https://beecalchub.com |
| April 18, 2026 | Switched nameservers from Namecheap to GoDaddy defaults |
| April 18, 2026 | DNS records added at GoDaddy pointing to Vercel |
| April 18, 2026 | Set up GitHub repository and auto-deployment |
| April 18, 2026 | Added Google Analytics tracking |
| April 18, 2026 | Verified first real-time visitor data (Calgary, AB) |

---

## 12. Account Logins Summary

Keep these credentials safe (consider using a password manager like Bitwarden, 1Password, or LastPass):

| Service | URL | Login |
|---|---|---|
| GoDaddy | https://godaddy.com | beecalchub@gmail.com |
| Vercel | https://vercel.com | Sign in with GitHub |
| GitHub | https://github.com | beecalchub@gmail.com (username: beecalchub) |
| Google Analytics | https://analytics.google.com | beecalchub@gmail.com |
| Buy Me a Coffee | https://buymeacoffee.com | beecalchub@gmail.com |
| Stripe | https://dashboard.stripe.com | beecalchub@gmail.com |
| Gmail (for site emails) | https://gmail.com | beecalchub@gmail.com |
| Namecheap (legacy, no longer used for DNS) | https://namecheap.com | (your account) |

---

## 13. Future To-Do / Ideas

- [ ] Submit sitemap to Google Search Console (https://search.google.com/search-console)
  - Verify ownership using Google Analytics (already set up)
  - Submit sitemap at https://beecalchub.com/sitemap.xml
- [ ] Create social media accounts to promote calculators
- [ ] Add more calculators based on user feature requests
- [ ] Cancel old Namecheap shared hosting plan if still active (no longer needed)
- [ ] Consider adding a Privacy Policy page (mentions Google Analytics use)

---

## 14. Analytics

### Google Analytics
- **Login:** https://analytics.google.com (sign in with beecalchub@gmail.com)
- **Account name:** BeeCalc Hub
- **Property name:** BeeCalc Hub Website
- **Measurement ID:** `G-2CPGZ55BT9`
- **Data stream URL:** https://beecalchub.com
- **Implementation:** `@next/third-parties/google` package
- **File modified:** `src/app/layout.tsx` (added `<GoogleAnalytics gaId="G-2CPGZ55BT9" />`)
- **Setup date:** April 18, 2026
- **First verified data:** April 18, 2026 (Calgary, AB - 3 active users)

### Useful Reports
| Report | What It Shows |
|---|---|
| **Realtime** | Who's on your site right now |
| **Reports → Engagement → Pages and screens** | Most popular calculators |
| **Reports → Acquisition → Traffic acquisition** | How people find your site |
| **Reports → User → Demographics** | Where your users are from |
| **Reports → Tech → Tech details** | Mobile vs desktop, browsers used |

### Note About Ad Blockers
About 30-40% of users have ad blockers that block Google Analytics. This is normal - GA still captures the majority of visitors. Don't disable your own ad blocker permanently to test - use Incognito mode instead.

---

## 15. Configuration Files

### .gitignore
**Location:** Project root  
**Purpose:** Tells Git which files/folders to ignore (never upload to GitHub)

Excludes:
- `node_modules/` (dependencies - regenerated by `npm install`)
- `.next/` (build output)
- `.env` files (secrets/credentials)
- IDE files (`.vscode/`, `.idea/`)
- OS files (`.DS_Store`, `Thumbs.db`)
- Vercel files (`.vercel`)

**Critical:** Never commit `node_modules/` - it's huge (140+ MB) and breaks GitHub pushes.

### .npmrc
**Location:** Project root  
**Contents:** `legacy-peer-deps=true`

**Purpose:** Tells npm to ignore peer dependency conflicts during install. Required because:
- Project uses `eslint` v8
- `eslint-config-next` v16 expects `eslint` v9
- Without this setting, Vercel's strict npm refuses to install

This setting matches the looser behavior of older npm versions (which is what Windows uses locally).

### Recovery Procedure (if node_modules accidentally gets committed)

If `git push` fails with "file too large" or "GH001: Large files detected":

1. **Verify .gitignore exists:**
   ```bash
   cd /c/WebVirtual/beecalc-hub
   cat .gitignore
   ```

2. **If missing, create it:**
   ```bash
   cat > .gitignore << 'EOF'
   node_modules/
   .next/
   .env
   .env.local
   *.log
   .DS_Store
   .vercel
   EOF
   ```

3. **Reset Git history (this is safe - keeps all your code files):**
   ```bash
   rm -rf .git
   git init
   git branch -M main
   git remote add origin https://github.com/beecalchub/beecalc-hub.git
   ```

4. **Add files and force push:**
   ```bash
   git add .
   git commit -m "Reset commit - clean history"
   git push --force origin main
   ```

This wipes the bad commit history and starts fresh. After this, regular `git push` works again.

---

## 16. The Standard Workflow

For making any change to the site, this is the daily workflow:

```bash
# 1. Open Git Bash and go to your project
cd /c/WebVirtual/beecalc-hub

# 2. (Optional) Test changes locally first
npm run dev
# Opens http://localhost:3000 - test in browser
# Press Ctrl+C to stop when done

# 3. Check what you changed
git status

# 4. Commit your changes
git add .
git commit -m "What you did (e.g., 'Update homepage text')"

# 5. Push to GitHub (triggers automatic Vercel deploy)
git push

# 6. Wait 2-4 minutes, check live site at https://beecalchub.com
```

---

**End of log. Keep this file safe!**

*Last updated April 18, 2026 - after completing GitHub setup, Vercel deployment, custom domain configuration, and Google Analytics integration.*
